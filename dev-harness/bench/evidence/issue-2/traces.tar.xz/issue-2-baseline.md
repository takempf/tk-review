Codemap bench "issue-2-baseline", 6800 files

Draw: the viewer's script per frame that drew. Input: per event. GPU raster: the GPU process rastering the canvas, per painted frame, and its p95 per displayed frame.
Frame p95 times the page's frames, which headless Chromium keeps at 16.7 even while the GPU falls behind: GPU raster p95 over 16.7 means the app drops frames.

| Scenario | Draw p50 ms | Draw p95 ms | Input p95 ms | GPU raster ms/frame | GPU raster p95 ms | Canvas calls/frame | Frame p95 ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3D · full range · highlighting on | 1.10 | 2.90 | 0.60 | 1.01 | 3.30 | 3617 | 16.8 |
| 3D · full range · highlighting off | 0.80 | 2.60 | 0.50 | 0.99 | 3.28 | 3615 | 16.8 |
| Flat · full range · highlighting on | 0.50 | 1.30 | 0.10 | 0.45 | 1.25 | 93 | 16.7 |
| Flat · full range · highlighting off | 0.30 | 0.90 | 0.10 | 0.43 | 1.17 | 99 | 16.8 |

Environment: {"cpu":"Apple M3 Pro","memoryGiB":36,"os":"darwin 27.2.0","browser":"153.0.8010.12","graph":{"repo":"monorepo","files":6801,"lines":1180383,"imports":32348},"visible":"6,003 files · 1.0M lines24,095 imports","userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.8010.12 Safari/537.36","viewport":[860,823],"dpr":2,"gpu":"ANGLE (Apple, ANGLE Metal Renderer: Apple M3 Pro, Unspecified Version)"}

3D · full range · highlighting on

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 5.20 | 16.8 | 17.70 |
| 4.7–20.0% | 53 | 5.10 | 16.8 | 17.80 |
| 20.0–37.0% | 23 | 1.10 | 16.8 | 17.70 |
| 37.0–48.0% | 10 | 1.10 | 16.7 | 17.80 |
| 48.0–100.0% | 27 | 1.50 | 16.8 | 17.70 |
| 100.0–267.0% | 37 | 0.90 | 16.8 | 18.30 |
| 267.0–520.0% | 25 | 0.70 | 16.7 | 17.50 |
| 520.0–667.0% | 9 | 0.90 | 16.7 | 17.40 |
| 667.0–1200.0% | 30 | 0.70 | 16.7 | 18.10 |

3D · full range · highlighting off

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 3.00 | 16.7 | 17.60 |
| 4.7–20.0% | 53 | 4.70 | 16.7 | 17.80 |
| 20.0–37.0% | 23 | 0.80 | 16.8 | 17.60 |
| 37.0–48.0% | 10 | 0.80 | 16.7 | 18.10 |
| 48.0–100.0% | 27 | 1.20 | 16.7 | 17.70 |
| 100.0–267.0% | 37 | 0.60 | 16.8 | 17.50 |
| 267.0–520.0% | 25 | 0.60 | 16.7 | 17.50 |
| 520.0–667.0% | 9 | 0.50 | 16.7 | 17.40 |
| 667.0–1200.0% | 30 | 0.50 | 16.8 | 17.50 |

Flat · full range · highlighting on

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 1.40 | 16.8 | 18.40 |
| 4.7–20.0% | 53 | 1.20 | 16.7 | 18.40 |
| 20.0–37.0% | 23 | 0.60 | 16.7 | 18.50 |
| 37.0–48.0% | 10 | 0.80 | 16.7 | 18.80 |
| 48.0–100.0% | 27 | 0.60 | 16.7 | 18.10 |
| 100.0–267.0% | 37 | 0.60 | 16.7 | 18.50 |
| 267.0–520.0% | 25 | 0.50 | 16.7 | 17.50 |
| 520.0–667.0% | 9 | 0.50 | 16.7 | 18.70 |
| 667.0–1200.0% | 30 | 0.50 | 16.8 | 17.40 |

Flat · full range · highlighting off

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 1.00 | 16.8 | 18.10 |
| 4.7–20.0% | 53 | 0.80 | 16.8 | 17.90 |
| 20.0–37.0% | 23 | 0.30 | 16.8 | 18.60 |
| 37.0–48.0% | 10 | 0.30 | 16.7 | 17.90 |
| 48.0–100.0% | 27 | 0.30 | 16.8 | 17.80 |
| 100.0–267.0% | 37 | 0.30 | 16.8 | 17.90 |
| 267.0–520.0% | 25 | 0.30 | 16.7 | 18.00 |
| 520.0–667.0% | 9 | 0.10 | 16.8 | 17.70 |
| 667.0–1200.0% | 30 | 0.20 | 16.7 | 17.80 |