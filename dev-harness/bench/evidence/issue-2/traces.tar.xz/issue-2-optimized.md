Codemap bench "issue-2-optimized", 6800 files, against "issue-2-baseline"

Draw: the viewer's script per frame that drew. Input: per event. GPU raster: the GPU process rastering the canvas, per painted frame, and its p95 per displayed frame.
Frame p95 times the page's frames, which headless Chromium keeps at 16.7 even while the GPU falls behind: GPU raster p95 over 16.7 means the app drops frames.

| Scenario | Draw p50 ms | Draw p95 ms | Input p95 ms | GPU raster ms/frame | GPU raster p95 ms | Canvas calls/frame | Frame p95 ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3D · full range · highlighting on | 1.10 → 0.90 (−18%) | 2.90 → 2.70 (−7%) | 0.60 → 0.50 (−17%) | 1.01 → 1.02 (+1%) | 3.30 → 2.34 (−29%) | 3617 → 3617 (−0%) | 16.8 → 16.7 (−1%) |
| 3D · full range · highlighting off | 0.80 → 0.80 (−0%) | 2.60 → 2.70 (+4%) | 0.50 → 0.50 (−0%) | 0.99 → 0.98 (−1%) | 3.28 → 3.27 (−0%) | 3615 → 3615 (−0%) | 16.8 → 16.7 (−1%) |
| Flat · full range · highlighting on | 0.50 → 0.30 (−40%) | 1.30 → 0.90 (−31%) | 0.10 → 0.10 (−0%) | 0.45 → 0.44 (−1%) | 1.25 → 1.23 (−1%) | 93 → 116 (+25%) | 16.7 → 16.7 (−0%) |
| Flat · full range · highlighting off | 0.30 → 0.20 (−33%) | 0.90 → 0.80 (−11%) | 0.10 → 0.10 (−0%) | 0.43 → 0.43 (−0%) | 1.17 → 1.22 (+4%) | 99 → 108 (+8%) | 16.8 → 16.7 (−1%) |

Environment: {"cpu":"Apple M3 Pro","memoryGiB":36,"os":"darwin 27.2.0","browser":"153.0.8010.12","graph":{"repo":"monorepo","files":6801,"lines":1180383,"imports":32348},"visible":"6,003 files · 1.0M lines24,095 imports","userAgent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/153.0.8010.12 Safari/537.36","viewport":[860,823],"dpr":2,"gpu":"ANGLE (Apple, ANGLE Metal Renderer: Apple M3 Pro, Unspecified Version)"}

3D · full range · highlighting on

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 4.40 | 16.7 | 18.40 |
| 4.7–20.0% | 53 | 4.90 | 16.8 | 18.40 |
| 20.0–37.0% | 23 | 0.90 | 16.7 | 18.00 |
| 37.0–48.0% | 10 | 0.90 | 16.7 | 17.70 |
| 48.0–100.0% | 27 | 1.40 | 16.7 | 18.30 |
| 100.0–267.0% | 37 | 0.60 | 16.8 | 18.50 |
| 267.0–520.0% | 25 | 0.60 | 16.7 | 18.30 |
| 520.0–667.0% | 9 | 0.60 | 16.8 | 17.60 |
| 667.0–1200.0% | 30 | 0.60 | 16.7 | 17.90 |

3D · full range · highlighting off

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 2.80 | 16.7 | 18.30 |
| 4.7–20.0% | 53 | 4.70 | 16.7 | 18.10 |
| 20.0–37.0% | 23 | 0.80 | 16.8 | 17.90 |
| 37.0–48.0% | 10 | 0.80 | 16.7 | 17.90 |
| 48.0–100.0% | 27 | 1.10 | 16.8 | 18.00 |
| 100.0–267.0% | 37 | 0.70 | 16.7 | 18.40 |
| 267.0–520.0% | 25 | 0.50 | 16.8 | 17.90 |
| 520.0–667.0% | 9 | 0.50 | 16.8 | 18.50 |
| 667.0–1200.0% | 30 | 0.60 | 16.7 | 17.90 |

Flat · full range · highlighting on

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 1.00 | 16.8 | 18.40 |
| 4.7–20.0% | 53 | 0.90 | 16.7 | 18.00 |
| 20.0–37.0% | 23 | 0.30 | 16.7 | 17.80 |
| 37.0–48.0% | 10 | 0.40 | 16.8 | 17.80 |
| 48.0–100.0% | 27 | 0.40 | 16.7 | 17.50 |
| 100.0–267.0% | 37 | 0.30 | 16.7 | 17.70 |
| 267.0–520.0% | 25 | 0.20 | 16.8 | 18.00 |
| 520.0–667.0% | 9 | 0.10 | 16.7 | 17.50 |
| 667.0–1200.0% | 30 | 0.20 | 16.8 | 18.20 |

Flat · full range · highlighting off

| Zoom | Frames | Draw p95 ms | Frame p95 ms | Input-to-draw p95 ms |
| --- | --- | --- | --- | --- |
| 0.2–4.7% | 116 | 0.90 | 16.7 | 17.80 |
| 4.7–20.0% | 53 | 0.90 | 16.7 | 18.10 |
| 20.0–37.0% | 23 | 0.20 | 16.8 | 17.80 |
| 37.0–48.0% | 10 | 0.30 | 16.7 | 18.00 |
| 48.0–100.0% | 27 | 0.30 | 16.7 | 17.70 |
| 100.0–267.0% | 37 | 0.20 | 16.8 | 18.50 |
| 267.0–520.0% | 25 | 0.30 | 16.7 | 18.30 |
| 520.0–667.0% | 9 | 0.20 | 16.7 | 17.40 |
| 667.0–1200.0% | 30 | 0.20 | 16.7 | 17.80 |

| Picture | Pixels changed |
| --- | --- |
| 3d-range-on | 0.00% |
| 3d-range-off | 0.00% |
| flat-range-on | 0.00% |
| flat-range-off | 0.00% |